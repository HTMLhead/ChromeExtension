function qs(part, value) {
  return part.querySelector(value)
}

export { qs }